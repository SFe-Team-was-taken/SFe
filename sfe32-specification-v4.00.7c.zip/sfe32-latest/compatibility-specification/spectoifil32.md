# SFe specification versions to SFe32 ifil versions 4.00

| SFe specification version | SFe32 ifil version (wMajor) | SFe32 ifil version (wMinor) |
| --- | --- | --- |
| 4.00 | 2 or 3 | 128 |
|     |     |     |
|     |     |     |
|     |     |     |
|     |     |     |
|     |     |     |
|     |     |     |
|     |     |     |
|     |     |     |