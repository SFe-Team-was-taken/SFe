# SFe32 file repair program specification 4.00.6

Implementation goal version 4.00.7.