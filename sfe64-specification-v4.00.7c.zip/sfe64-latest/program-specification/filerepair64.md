# SFe file repair program specification

Implementation goal version 4.00.6.